package com.model;

public class Booking {
		public static int Flight_ID;
	 	public static String Flight_Date;
	 	public static String Flight_Source;
	 	public static String Flight_Destination;
	    public static int Flight_Price;
	    public static String Airline;
	    public static int Passengers;
	    public static String pname;
	    public static String email;


	    
}
